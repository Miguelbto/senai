# -*- coding: UTF-8 -*-

print("Me de um numero")
vlr = float (input("Digite o numero: "))

if vlr % 3 == 0:
    print("O número é multiplo de 3")

else:
    print("Seu número não é multiplo de 3")
  

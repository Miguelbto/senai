# -*- coding: UTF-8 -*-

print("Me de um número inteiro que irei dizer se é um número ímpar ou par")
vlr = int (input("Digite o valor: "))

if vlr % 3 == 0:
    print("Seu número é ímpar")

else:
    print("Seu número é par")

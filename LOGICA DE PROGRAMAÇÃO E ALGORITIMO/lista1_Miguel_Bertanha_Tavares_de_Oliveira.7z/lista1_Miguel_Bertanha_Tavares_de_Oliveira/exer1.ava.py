# -*- coding: UTF-8 -*-

print("Me digite um valor para que eu consiga fazer uma operação para você")
vlr = int (input("Digite um valor: "))

if vlr>21:
    print("O seu valor irá fazer uma adição com número 8")
    conta = vlr + 8
    print("Seu valor será de: ", conta)
    
elif vlr<=20:
    print("Seu valor irá subtrair com número 5")
    conta1 = vlr - 5
    print("Seu valor será de: ", conta1)

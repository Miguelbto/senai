# -*- coding: UTF-8 -*-

print("Me dois números inteiros e direi o maior entre eles")
v1 = int (input("Digite o primeiro número: "))
v2 = int (input("Digite o segundo número: "))

if v1 > v2:
    print("O primeiro número é maior")

else:
    print("O segundo número é maior")

# -*- coding: UTF-8 -*-


print("Me iforme a temperatura do dia")
clima = int (input("Me informe a temperatura °C: "))

if clima <=15:
    print("Está muito frio o dia")

elif clima <=23:
    print("Está frio o dia")

elif clima <=26:
    print("Está agradável o clima")

elif clima <=30:
    print("Está quente o dia")

elif clima >=31:
    print("Está muito quente o dia")
    

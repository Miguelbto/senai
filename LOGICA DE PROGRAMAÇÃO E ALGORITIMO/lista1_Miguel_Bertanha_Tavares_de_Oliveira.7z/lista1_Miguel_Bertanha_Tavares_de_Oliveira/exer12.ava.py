# -*- coding: UTF-8 -*-

print(" me dê duas variaveis inteiras ")
v1 = int(input("variavel 1:"))
v2 = int(input("variavel 2:"))
if v1 > v2:
    print("ordem crescente é de:", v2 , v1)
else :
    print("ordem crescente é de:", v1 ,v2)

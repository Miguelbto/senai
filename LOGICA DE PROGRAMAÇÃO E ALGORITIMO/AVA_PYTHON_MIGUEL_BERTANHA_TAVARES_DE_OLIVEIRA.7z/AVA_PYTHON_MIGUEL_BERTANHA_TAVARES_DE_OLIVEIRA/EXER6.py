#-*-coding: UTF-8-*-



print("digite um número inteiro positivo para que eu faça a soma do 1 até esse número")

num = int(input("digite um número: "))
x = 0
x1 = 0

while x <= num:
    print(f"{x} + 1 = {x}")
    x = x + 1
    if x == x:
        x1 = x1 + x -1
        print(x1)



    




#-*-coding: UTF-8-*-


print("insira sua idade para que eu informe em quantos anos irá ter 100 anos")

idade = int(input("insira sua idade: "))

soma = 100 - idade 

print(f"Você terá 100 anos, daqui {soma} anos")

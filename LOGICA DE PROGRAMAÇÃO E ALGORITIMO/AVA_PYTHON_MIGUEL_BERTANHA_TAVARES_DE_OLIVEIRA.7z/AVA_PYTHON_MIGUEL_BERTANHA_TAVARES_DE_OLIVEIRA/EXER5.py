#-*-coding: UTF-8-*-


print("insira um número inteiro para que eu informe a tabuada dele")

num = int(input("qual número você deseja: "))

for x in range (0,11,1):
    print(f"{num} X {x} = {num * x}")
    






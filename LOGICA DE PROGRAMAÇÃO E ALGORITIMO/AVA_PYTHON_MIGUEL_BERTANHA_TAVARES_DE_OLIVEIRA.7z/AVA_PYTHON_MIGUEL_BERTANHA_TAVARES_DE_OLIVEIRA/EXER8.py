#-*-coding: UTF-8-*-



print("escreva um número para que eu mostre do número 1 até o número inserido")

num = int(input("digite um número para a contagem: "))

x = 1

while x <= num:
    print(x)
    x = x + 1

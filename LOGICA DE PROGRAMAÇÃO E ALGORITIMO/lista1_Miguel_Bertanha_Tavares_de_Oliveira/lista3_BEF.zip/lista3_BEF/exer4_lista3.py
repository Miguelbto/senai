# -*- coding: UTF-8 -*-

cont = int(input("insira um número para que eu faça a contagem dele até zero: "))

def contagem(x):
    for v in range (cont, -1, -1):
        print(f" contagem regressiva: {v}")
contagem(cont)
print("Feliz ano novo!")








  
